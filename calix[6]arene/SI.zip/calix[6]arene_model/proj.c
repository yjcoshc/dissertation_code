#include <math.h>
#include <tcl.h>

typedef struct Vector_struct
{
    double x;
    double y;
    double z;
} Vector;

double dot(Vector A, Vector B) {
    return A.x * B.x + A.y * B.y + A.z * B.z;
}

int Projection_Cmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[]) {
    /*1-6: ring; 7: plane*/
    int length[7];
    Tcl_Obj** elem[7];
    for (int i = 0; i < 7; ++i) {
        Tcl_ListObjGetElements(interp, objv[i+1], &length[i], &elem[i]);
    }
    Vector vec[7];
    for (int i = 0; i < 7; ++i) {
        Tcl_GetDoubleFromObj(interp, elem[i][0], &(vec[i].x));
        Tcl_GetDoubleFromObj(interp, elem[i][1], &(vec[i].y));
        Tcl_GetDoubleFromObj(interp, elem[i][2], &(vec[i].z));
    }
    double proj = 0;
    for (int i = 0; i < 6; ++i) {
        proj += dot(vec[i], vec[6]);
    }
    Tcl_Obj *res = Tcl_NewDoubleObj(proj);
    Tcl_SetObjResult(interp, res);
    return TCL_OK;
}

int ProjectionGrad_Cmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[]) {
    /*1-6: ring; 7: plane*/
    int length[7];
    Tcl_Obj** elem[7];
    for (int i = 0; i < 7; ++i) {
        Tcl_ListObjGetElements(interp, objv[i+1], &length[i], &elem[i]);
    }
    Vector vec[7];
    for (int i = 0; i < 7; ++i) {
        Tcl_GetDoubleFromObj(interp, elem[i][0], &(vec[i].x));
        Tcl_GetDoubleFromObj(interp, elem[i][1], &(vec[i].y));
        Tcl_GetDoubleFromObj(interp, elem[i][2], &(vec[i].z));
    }
    Tcl_Obj *res = Tcl_NewListObj(0, NULL);
    Tcl_Obj *dr = Tcl_NewListObj(0, NULL);
    Tcl_Obj *dp = Tcl_NewListObj(0, NULL);
    Tcl_ListObjAppendElement(interp, dr, Tcl_NewDoubleObj(vec[6].x));
    Tcl_ListObjAppendElement(interp, dr, Tcl_NewDoubleObj(vec[6].y));
    Tcl_ListObjAppendElement(interp, dr, Tcl_NewDoubleObj(vec[6].z));
    Tcl_ListObjAppendElement(interp, dp, Tcl_NewDoubleObj(vec[0].x + vec[1].x + vec[2].x + vec[3].x + vec[4].x + vec[5].x));
    Tcl_ListObjAppendElement(interp, dp, Tcl_NewDoubleObj(vec[0].y + vec[1].y + vec[2].y + vec[3].y + vec[4].y + vec[5].y));
    Tcl_ListObjAppendElement(interp, dp, Tcl_NewDoubleObj(vec[0].z + vec[1].z + vec[2].z + vec[3].z + vec[4].z + vec[5].z));
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dr);
    Tcl_ListObjAppendElement(interp, res, dp);
    Tcl_SetObjResult(interp, res);
    return TCL_OK;
}

int Proj_Init(Tcl_Interp *interp) {
    if (Tcl_InitStubs(interp, TCL_VERSION, 0) == NULL) {
        return TCL_ERROR;
    }
    if (Tcl_PkgProvide(interp, "Proj", "1.0") == TCL_ERROR) {
        return TCL_ERROR;
    }
    Tcl_CreateObjCommand(interp, "calc_project_to_vector", Projection_Cmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "calc_project_to_vector_gradient", ProjectionGrad_Cmd, NULL, NULL);
    return TCL_OK;
}

